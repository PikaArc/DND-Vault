### Deer

*Medium beast, unaligned*

**Armor Class** 13

**Hit Points** 4 (1d8)

**Speed** 50 ft.

| STR     | DEX     | CON     | INT    | WIS     | CHA    |
|---------|---------|---------|--------|---------|--------|
| 11 (+0) | 16 (+3) | 11 (+0) | 2 (-4) | 14 (+2) | 5 (-3) |

**Senses** passive Perception 12

**Languages** -

**Challenge** 0 (10 XP)

###### Actions

***Bite***. *Melee Weapon Attack:* +2 to hit, reach 5 ft., one target. *Hit:* 2 (1d4) piercing damage.